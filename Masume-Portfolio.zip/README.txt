Masume Soltani — Bilingual UI/UX Portfolio

Open dist/index.html in a modern browser, or serve dist with a static web server.
No build step or installation is required.

Features: Persian RTL and English LTR, responsive layout, three case studies,
actual prototype screenshots, accessible image viewer, downloadable resume,
email and LinkedIn links.

Screenshots are captured from the actual projects. Zarfiyat uses demonstration
income and purchase data created in the preview browser, not personal finances.
Claude prototype links may require the visitor to sign in.

Rooyin Persian pixel font: MohamadDarvishi/Rooyin, SIL Open Font License.
Font license is included in dist/assets/Rooyin-OFL.txt.

Resume and professional background are based on the user-supplied Resume.pdf.
No employment dates, user interview results or conversion metrics were invented.

Visual direction: cream and ink blue, restrained retro window details.
Content reference: mobinamohseni.studio.site, adapted to the user's own projects.
